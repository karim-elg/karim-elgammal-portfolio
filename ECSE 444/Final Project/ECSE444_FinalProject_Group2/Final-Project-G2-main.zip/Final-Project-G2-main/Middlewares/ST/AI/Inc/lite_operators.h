#ifndef LITE_OPERATORS_H
#define LITE_OPERATORS_H
#pragma once

#include "lite_dense_if32.h"
#include "lite_dense_is1.h"
#include "lite_dense_is1ws1.h"
#include "lite_dense_ws1.h"


#include "lite_nl_generic_float.h"
#include "lite_nl_generic_integer.h"
#include "lite_generic_float.h"

#endif /* LITE_OPERATORS_H */
